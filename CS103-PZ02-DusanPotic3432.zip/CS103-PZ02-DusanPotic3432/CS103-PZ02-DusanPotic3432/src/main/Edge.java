/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author Dusan
 */
public class Edge {

    private final Node start;
    private final Node end;
    private final int cost;

    public Edge(Node start, Node end, int cost) {
        this.start = start;
        this.end = end;
        this.cost = cost;
    }

    public Node getEnd() {
        return end;
    }

    public Node getStart() {
        return start;
    }

    public int getCost() {
        return cost;
    }

    @Override
    public String toString() {
        return start + " " + end;
    }

}
