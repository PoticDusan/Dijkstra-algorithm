/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Stack;
import java.util.Set;

/**
 *
 * @author Dusan
 */
public class Dijkstra {

    private final List<Node> nodes;
    private final List<Edge> edges;
    
    private ArrayList<Node> visited;
    private Set<Node> unvisited;
    
    private Map<Node, Node> path;
    private Map<Node, Integer> cost;

    public Dijkstra(Graph graph) {
        this.nodes = new ArrayList<Node>(graph.getNodes());
        this.edges = new ArrayList<Edge>(graph.getEdges());
    }

    public void run(Node start) {
        
        visited = new ArrayList<Node>();
        unvisited = new HashSet<Node>();
        cost = new HashMap<Node, Integer>();        
        path = new HashMap<Node, Node>();           
        cost.put(start, 0);                             // 0 jer je pocetna
        unvisited.add(start);                           //oznacimo je da nije posecena
        while (unvisited.size() > 0) {
            Node node = getMinimum(unvisited);         //uzimamo minimum od neposecenih
            visited.add(node);                         //sada je ona posecena
            unvisited.remove(node);                    //nije vise neposecena
            findMinimalDistances(node);                //nadji najmanju duzine iz tog cvora
        }
    }

    //nadji najmanje tezine grana || uporedjivanjem prethodne sa novom tezinom
    private void findMinimalDistances(Node node) {
        List<Node> listaSusedstva = getListaSusednih(node);
        for (Node target : listaSusedstva) {
            if (getShortestDistance(target) > getShortestDistance(node) + getDistance(node, target)) {
                cost.put(target, getShortestDistance(node) + getDistance(node, target));
                path.put(target, node);
                unvisited.add(target);
            }
        }
    }

    //vrati tezinu grane izmedju dva cvora
    private int getDistance(Node node, Node target) {
        for (Edge edge : edges) {
            if (edge.getStart().equals(node) && edge.getEnd().equals(target)) {
                return edge.getCost();
            }
        }
        return 0;
    }
    
    //vrati listu cvorova koji su susedi datog cvora a nisu poseceni
    private List<Node> getListaSusednih(Node node) {
        List<Node> listaSusedstva = new ArrayList<Node>();
        for (Edge edge : edges) {
            if (edge.getStart().equals(node) && !isVisited(edge.getEnd())) {
                listaSusedstva.add(edge.getEnd());
            }
        }
        return listaSusedstva;
    }
    
    //vrati cvor sa minimalnom tezinom 
    private Node getMinimum(Set<Node> nodes) {
        Node minimum = null;
        for (Node n : nodes) {
            if (minimum == null) {
                minimum = n;
            } else {
                if (getShortestDistance(n) < getShortestDistance(minimum)) {
                    minimum = n;
                }
            }
        }
        return minimum;
    }
    
    //da li je cvor posecen
    private boolean isVisited(Node node) {
        return visited.contains(node);
    }
    
    //vrati tezinu najkrace putanje do datog cvora
    private int getShortestDistance(Node target) {
        Integer distance = cost.get(target);
        if (distance == null) {
            return Integer.MAX_VALUE;
        } else {
            return distance;
        }
    }
    
    //vrati putanju po cvorovima
    public LinkedList<Node> getPath(Node node) {
        LinkedList<Node> finalPath = new LinkedList<Node>();
        Node newNode = node;
        if (this.path.get(newNode) == null) {                                   
            return null;
        }
        finalPath.add(newNode);                                                 
        while (this.path.get(newNode) != null) {
            newNode = this.path.get(newNode);
            finalPath.add(newNode);
        }
        Collections.reverse(finalPath);
        return finalPath;
    }
}
