/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

/**
 *
 * @author Dusan
 */
public class Main extends Application {

    private List<Node> nodes;
    private List<Edge> edges;

    @Override
    public void start(Stage primaryStage) {
        Button btnFind = new Button("Find path");
        TextField txtStart = new TextField();
        TextField txtEnd = new TextField();
        Image img = new Image("http://i63.tinypic.com/1zo89s2.png");

        HBox h = new HBox(txtStart, txtEnd, btnFind);
        h.setSpacing(10);
        h.setPadding(new Insets(10));

        BorderPane root = new BorderPane();
        BackgroundSize bSize = new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, false);

        root.setBackground(new Background(new BackgroundImage(img,
                BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.CENTER,
                bSize)));

        root.setBottom(h);
        Scene scene = new Scene(root, 700, 400);
        primaryStage.setTitle("IT350-PZ02");
        primaryStage.setScene(scene);
        primaryStage.show();

        btnFind.setOnAction((e) -> {
            nodes = new ArrayList<>();
            edges = new ArrayList<>();

            String[] city = {"Seattle", "San Francisco", "Los Angeles", "Denver", "Kansas City",
                "Chicago", "Boston", "New York", "Atlanta", "Miami", "Dalas", "Huston"};

            for (int i = 0; i < city.length; i++) {
                Node cvor = new Node("Cvor -" + i, city[i]);
                nodes.add(cvor);
            }

            addEdge(0, 1, 807);
            addEdge(0, 3, 1331);
            addEdge(0, 5, 2097);
            addEdge(1, 2, 381);
            addEdge(1, 3, 1267);
            addEdge(2, 3, 1015);
            addEdge(2, 4, 1663);
            addEdge(3, 4, 599);
            addEdge(2, 10, 1435);
            addEdge(4, 10, 496);
            addEdge(4, 5, 533);
            addEdge(3, 5, 1003);
            addEdge(4, 7, 1260);
            addEdge(5, 7, 787);
            addEdge(4, 8, 864);
            addEdge(10, 8, 781);
            addEdge(11, 8, 810);
            addEdge(11, 9, 1187);
            addEdge(9, 8, 661);
            addEdge(8, 7, 888);
            addEdge(7, 6, 214);
            addEdge(11, 10, 239);

            Graph graph = new Graph(nodes, edges);
            Dijkstra d = new Dijkstra(graph);

            d.run(nodes.get(Integer.parseInt(txtStart.getText())));
            LinkedList<Node> path = d.getPath(nodes.get(Integer.parseInt(txtEnd.getText())));
            System.out.println("Result:");
            System.out.println("From:\n_________________");
            for (Node node : path) {
                System.out.println(node);
            }
            System.out.println("_________________\nEnd");

        });
    }

    private void addEdge(int start, int end, int tezina) {
        Edge grana = new Edge(nodes.get(start), nodes.get(end), tezina);
        Edge grana2 = new Edge(nodes.get(end), nodes.get(start), tezina);
        edges.add(grana);
        edges.add(grana2);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
