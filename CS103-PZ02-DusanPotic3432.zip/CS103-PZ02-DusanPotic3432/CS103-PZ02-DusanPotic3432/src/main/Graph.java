/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.util.List;

/**
 *
 * @author Dusan
 */
public class Graph {
    private final List<Node> nodes;
    private final List<Edge> edges;

    public Graph(List<Node> vertexes, List<Edge> edges) {
        this.nodes = vertexes;
        this.edges = edges;
    }

    public List<Node> getNodes() {
        return nodes;
    }

    public List<Edge> getEdges() {
        return edges;
    }



}